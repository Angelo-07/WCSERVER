var myLogModule = require('./Utility');

myLogModule.info('NodeJS is currently running...');